from Stack import Stack:
class Person:
        def __init__(self,name,age):
            self.name = name
            self.age = age
class Stack:
    def __init__(self):
        self.items = []
        
    def is_empty(self):
        return len(self.items) == 0
    
    def push(self, item):
        self.item.append(item)
        
    def pop(self):
        if not self.is_empty():
            return self.items[-1]
        
    def size(self):
        return len(self.items)
    #---------------------------------
    
def add_guest(guestList, person):
    guestList.push(person)
    print(f"[person.name} has been added to the guest list. ")
    
    
def remove_guest(guestList, person):
    guestList.pop(person)
    print(f"{remove_guest.name} has been removed from the guest list.")


def guestCount(guestList):
    count = guestList.size()
    print(f"Number of current guests: {count}")
    
def viewGuest(guestList):
    print("Guest list: ")
    for i in guestList.items[::-1]:
        print(guest.name)
        
guestList = Stack()
p1 = Person("Fatma", 59)
p2 = Person("amina", 23)
p3 = Person("mariam", 21)

add_guest(guestList, p1)
add_guest(guestList, p2)
add_guest(guestList, p3)

guestCount(guest_list)

viewGuest(guest_list)

remove_guest(guest_list)

viewGuest(guest_list)
        
        
    