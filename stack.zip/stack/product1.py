class product:
    #constructor
    def __init__(self,name,category, price):# ---> called parameters 
        self.name = name
        self.category = category
        self.price = price 

    def getName(self):
        return self.name
    
    def getCategory(self):
        return self.category
    
    def getPrice(self):
        return self.price

    def setName(self, newName):
        self.name = newName
    
    def setPrice(self, newPrice):
        self.price = newPrice 

    def descripe(self):
        return f"the product {self.name} is a {self.category} and it costs {self.price}OR"

    def compute_discount(self,amount):
        amount = self.price - (self.price * amount/100)
        if self.category == "Electronics":
            self.price += 10
    

    

