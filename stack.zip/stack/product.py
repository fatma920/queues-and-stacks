import pandas as pd
from product1 import product
from StackClass import Stack
#assuming  already have data into excel file into dataframe df
df = pd.read_excel('Reading.xlsx', sheet_name='products')
print("%20s%20s%10.2f" %("productName","category","Price" ))
print("-"*50)
pList = []

for index, row in df.iterrows():
    productName = row['pName']
    category = row['Category']
    Price = row['Price']
    currentproduct = product(productName, category, Price)
    pList.append(currentproduct)
    print(currentproduct.descripe())
    print("after: ",currentproduct.compute_discount(5))
    print("%-20s%-20s%-10.2f" %(productName,category,Price ))
    print(productName, " ", category, "  ",Price)
    
#outside the loop
print("size of stack", productStack.size())
print(len(pList))
for p in pList:
    print("%-20s%-20s%-10.2f" %(product.getName(),product.getCategory(),product.getPrice())
print("===================")
while not productStack.is_empty():